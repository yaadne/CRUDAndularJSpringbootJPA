var mymodule=angular.module('myservices',[]);
mymodule.service('DeptService',function($http){
    
    this.getDeptDetailsService=function(cb)
{
    var url="http://localhost:8080/employee/getDepartments"
    console.log("fetching departments ..")
    var responseDataDepts="Data is arriving"
    $http.get(url).then(function(response)
    {
        responseDataDepts=response.data
        console.log(responseDataDepts)
        cb(responseDataDepts)
        

        
    })
   
}




})