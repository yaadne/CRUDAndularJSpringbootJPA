package com.example.employee.employeedao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.employee.employeedo.EmployeeDepartment;

public interface DepartmentDao  extends JpaRepository<EmployeeDepartment, Integer>{
	

}
