package com.example.employee.controllers;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.employee.employeedao.DepartmentDao;
import com.example.employee.employeedao.EmployeeDao;
import com.example.employee.employeedo.EmployeeContact;
import com.example.employee.employeedo.EmployeeDepartment;
import com.example.employee.employeedo.EmployeeDo;

@org.springframework.web.bind.annotation.RestController
public class RestController {
	@Autowired
	EmployeeDao empRep;
	
	@Autowired
	DepartmentDao deptRep;
	
	
	@GetMapping("employee/fetchAll")
	ResponseEntity<List<EmployeeDo>> findAllEmp()
	{
		List<EmployeeDo> empList=empRep.findAll();
		return new ResponseEntity<List<EmployeeDo>>(empList, HttpStatus.OK);
	}
	
	@PostMapping("employee/addByBody")
	public void addByBody() throws ParseException
	{
		String sDate1="2016-08-16";
		LocalDate date1=LocalDate.parse(sDate1);
		EmployeeDo emp=new EmployeeDo("Male","asd", "asdd",date1, 123);
		emp.setContactId(new EmployeeContact("asd@@",1234, "asdasd"));
		emp.setDeptId(new EmployeeDepartment("Operations", "Pune"));
		empRep.save(emp);
		
	}
	@PostMapping("employee/addByBodyCustom")
	public void addByBody(@RequestBody EmployeeDo empObj) throws ParseException
	{
		//String sDate1="2016-08-16";
		//LocalDate date1=LocalDate.parse(date2, df);
		
	
		
		EmployeeDo emp=new EmployeeDo(empObj.getGender(),empObj.getEmpFirstName(),empObj.getEmpLastName(),empObj.getDate(),empObj.getSal());
		emp.setContactId(new EmployeeContact(empObj.getContactId().getEmail(),empObj.getContactId().getPhoneNo(), empObj.getContactId().getAddress()));
		System.out.println(empObj.getDeptId());
		
		empRep.save(empObj);
		
		
		
	}
	@DeleteMapping("employee/deleteByEmpId/{empId}")
	@Transactional
	public void deleteByEmpId(@PathVariable("empId") int empId)
	{
		empRep.deleteByEmpId(empId);
	}
	
	@PostMapping("employee/update")
	public void updateEmpByBody(@RequestBody EmployeeDo empObj)
	{
		System.out.println(empObj.getEmpFirstName());

		System.out.println(empObj.getDeptId().getDeptName()+" "+empObj.getDeptId());
		System.out.println(empObj.getContactId().getPhoneNo());
		System.out.println(empObj.getDate());
		empRep.save(empObj);
	}
	@GetMapping("employee/searchByName/{empName}")
	ResponseEntity<List<EmployeeDo>> findEmpByName(@PathVariable("empName") String empName)
	{
		System.out.println(empName);
		List<EmployeeDo> empList=empRep.findByEmpFirstName(empName);
		return new ResponseEntity<List<EmployeeDo>>(empList,HttpStatus.OK);
	
	}
	@PostMapping("employee/deleteByEmpId/{empId}")
	@Transactional
	public void deleteByEmpId2(@PathVariable("empId") int empId)
	{
		empRep.deleteByEmpId(empId);
	}
	
	@GetMapping("employee/getDepartments")
	ResponseEntity <List<EmployeeDepartment>> getDepartments()
	{
		List<EmployeeDepartment> deptList=deptRep.findAll();
		System.out.println(deptList);
		return new ResponseEntity<List<EmployeeDepartment>>(deptList,HttpStatus.OK);
 	}
	
}
