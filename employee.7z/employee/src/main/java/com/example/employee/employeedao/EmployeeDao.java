package com.example.employee.employeedao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.employee.employeedo.EmployeeDo;

public interface EmployeeDao extends JpaRepository<EmployeeDo, Integer> {
	
	public List<EmployeeDo> findAll();
	public List<EmployeeDo> deleteByEmpId(int empId);
	public List<EmployeeDo> findByEmpFirstName(String empName);

}
