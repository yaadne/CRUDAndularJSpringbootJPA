package com.example.employee.employeedo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.transaction.Transactional;

@Entity
@Table(name="employee_department")
@Transactional
public class EmployeeDepartment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int deptId;
	
	private String deptName,loc;

	public int getDeptId() {
		return deptId;
	}
	@Column(name="dept_id")
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}
	@Column(name="dept_name")
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getLoc() {
		return loc;
	}

	public EmployeeDepartment(int deptId, String deptName, String loc) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
		this.loc = loc;
	}

	public EmployeeDepartment() {
		super();
	}
	@Column(name="dept_loc")
	public void setLoc(String loc) {
		this.loc = loc;
	}

	@Override
	public String toString() {
		return "EmployeeDepartment [deptId=" + deptId + ", deptName=" + deptName + ", loc=" + loc + "]";
	}
	public EmployeeDepartment(String deptName, String loc) {
		super();
		this.deptName = deptName;
		this.loc = loc;
	}
	
	
	
	

}
