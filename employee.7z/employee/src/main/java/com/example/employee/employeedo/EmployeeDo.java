package com.example.employee.employeedo;



import java.time.LocalDate;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import javax.transaction.Transactional;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@Entity
@Table(name="employee")
@Transactional
public class EmployeeDo {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int empId;
	
	private String gender;
	
	public String getGender() {
		return gender;
	}
	@Column(name="employee_gender")
	public void setGender(String gender) {
		this.gender = gender;
	}
	private String empFirstName,empLastName;
	@JsonDeserialize(as = LocalDate.class)
	@DateTimeFormat(pattern = "yyyy-MM-dd", iso = ISO.DATE_TIME)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	 private LocalDate date;
	 
	 
	
	private int sal;
	
	public LocalDate getDate() {
		return date;
	}
	@Column(name="emp_hiredate")
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="contact_id",referencedColumnName = "contactId")
	private EmployeeContact contactId;
	 
	@ManyToOne
	@JoinColumn(name="dept_id",referencedColumnName = "deptId", updatable = true)
	private EmployeeDepartment deptId;
	 
	 
	public EmployeeContact getContactId() {
		return contactId;
	}
	public void setContactId(EmployeeContact contactId) {
		this.contactId = contactId;
	}
	public int getEmpId() {
		return empId;
	}
	@Column(name="emp_id")
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	@Column(name="emp_first_name")
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	@Column(name="emp_last_name")
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	
	public int getSal() {
		return sal;
	}
	@Column(name="emp_sal")
	public void setSal(int sal) {
		this.sal = sal;
	}
	public EmployeeDo() {
		super();
	}

	
	@Override
	public String toString() {
		return "EmployeeDo [empId=" + empId + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", sqlDate=" + date + ", sal=" + sal + "]";
	}
	
	public EmployeeDo(String gender, String empFirstName, String empLastName, LocalDate date, int sal) {
		super();
		this.gender = gender;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.date = date;
		this.sal = sal;
	}
	public EmployeeDepartment getDeptId() {
		return deptId;
	}
	public void setDeptId(EmployeeDepartment deptId) {
		this.deptId = deptId;
	}
	 
	


}
