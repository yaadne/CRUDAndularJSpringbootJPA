package com.example.employee.aop;

import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Component
@EnableAspectJAutoProxy
@Aspect
public class Logging {
	
	
	@Pointcut("execution(* com.example.employee.controllers.RestController.findAllEmp())")
	private void selectAll()
	{
		
	}
	
	@Pointcut("execution(* com.example.employee.controllers.RestController.*(..))")
	private void forAllMethodsInRestController()
	{
		
	}
	
	@Before("forAllMethodsInRestController()")
	public void interceptDataBeforeAdvice(JoinPoint jp)
	{
		System.out.println(jp.getSignature()+" method was called at "+ new Date());
		Object [] args=jp.getArgs();
		if(args.length >0)
			System.out.println("argument "+args[0]);
				
	}
	
	
	@Before("forAllMethodsInRestController()")
	public void forAllBefore()
	{
		System.out.println("Interceptor for all methods before ");
	}
	
	@Before("selectAll()")
	public void testBefore()
	{
		System.out.println("Point Cut has selected a method and advise is before the method gets excuted");
	}
	
	@After("selectAll()")
	public void testAfter()
	{
		System.out.println("Point Cut selected method is intercepted  after advise ");
	}
	
	@AfterReturning(pointcut="forAllMethodsInRestController()",returning="returnVal")
	public void afterAdvice(JoinPoint jp,Object returnVal)
	{
		System.out.println(jp.getSignature()+" returned :"+returnVal);
	}
	
	@Around(value="forAllMethodsInRestController()")
	public Object aroundAdvise(ProceedingJoinPoint jp)throws Throwable
	{
		System.out.println("around prior to call"+jp.getSignature());
		
		Object return_value=null;
		return_value=jp.proceed();// the intercepted method is called we can block the call if it is malicious
		System.out.println("around at the end of the call"+jp.getSignature() );
		return return_value;
				
	}
	
}
