package com.example.employee.employeedo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.transaction.Transactional;

@Entity
@Table(name="employee_contact")
@Transactional
public class EmployeeContact {
	
	
	public EmployeeContact() {
		super();
		
	}

	public EmployeeContact(String email, long phoneNo, String address) {
		super();
		
		this.email = email;
		this.phoneNo = phoneNo;
		this.address = address;
	}

	public EmployeeContact(int contactId, String email,long phoneNo, String address) {
		super();
		this.contactId = contactId;
		this.email = email;
		this.phoneNo = phoneNo;
		this.address = address;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int contactId;
	private String email;
	private long phoneNo;
	private String address;
	public int getContactId() {
		return contactId;
	}
	
	public void setContactId(int contactId) {
		this.contactId = contactId;
	}
	public String getEmail() {
		return email;
	}
	@Column(name="emp_email")
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	@Column(name="emp_phone_number")
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	@Column(name="emp_address")
	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "EmployeeContact [contactId=" + contactId + ", email=" + email + ", phoneNo=" + phoneNo + ", address="
				+ address + "]";
	}

}
